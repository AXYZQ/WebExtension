

function cancel(requestDetails) {
	console.log(`Script file : ${requestDetails.url}`);
	return { cancel: false };
}

browser.webRequest.onBeforeRequest.addListener(
	 cancel,
	{ urls: ["<all_urls>"	], types: ["script"] },
	["blocking"],
);





