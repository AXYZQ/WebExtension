let pattern = "https://www.jma.go.jp/bosai/ad/*";

function redirect(requestDetails) {
	console.log(`blocked: ${requestDetails.url}`);
	return { cancel: true };
}

browser.webRequest.onBeforeRequest.addListener(
  redirect,
  { urls: [pattern], types: ["script"] },
  ["blocking"],
);





