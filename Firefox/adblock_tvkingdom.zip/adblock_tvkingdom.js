
console.log(`start : `);

const pattern = new URLPattern({
  hostname: "{*.}?tvkingdom.jp",
});

//let pattern = "https://www.tvkingdom.jp/m/*";


function cancel(requestDetails) {
	//console.log(`pattern : ` + requestDetails.url + ` - ` +(

//requestDetails.url === "*://*.tvkingdom.jp/"

//));

//console.log(`pattern : ` + requestDetails.url + ` - ` + pattern.test(requestDetails.url));


	if (pattern.test(requestDetails.url)) {
		console.log(`through : ${requestDetails.url}`);
		return { cancel: false };
	};

	console.log(`canceled : ${requestDetails.url}`);
	return { cancel: true };
}



browser.webRequest.onBeforeRequest.addListener(
	 cancel,
	{ urls: ["https://anymind360.com/*",
			"https://securepubads.g.doubleclick.net/*",
			"https://pagead2.googlesyndication.com/*",
			"https://cdn.gmossp-sp.jp/*"
	], types: ["script"] },
	["blocking"],
);





