
const pattern = new URLPattern({hostname: "{*.}?tvkingdom.jp"});

function cancel(requestDetails) {
	if (pattern.test(requestDetails.url)) {
		//console.log(`through : ${requestDetails.url}`);
		return { cancel: false };
	};

	console.log(`blocked : ${requestDetails.url}`);
	return { cancel: true };
}

browser.webRequest.onBeforeRequest.addListener(
	 cancel,
	{ urls: ["https://anymind360.com/*",
			"https://securepubads.g.doubleclick.net/*",
			"https://pagead2.googlesyndication.com/*",
			"https://cdn.gmossp-sp.jp/*"
	], types: ["script"] },
	["blocking"],
);





